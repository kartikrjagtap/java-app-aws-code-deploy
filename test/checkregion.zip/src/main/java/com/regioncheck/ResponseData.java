package com.regioncheck;

import java.util.List;

public class ResponseData{
	
	private List<Data> data;
	
	public ResponseData() {}

	public List<Data> getData() {
		return data;
	}

	public void setData(List<Data> data) {
		this.data = data;
	}
	
	
}
